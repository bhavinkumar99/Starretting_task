//
//  ViewController.swift
//  star_retingwith_tableviewcell
//
//  Created by Setblue's iMac on 03/04/19.
//  Copyright © 2019 I MAC. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    var finalarr:[[String:Any]] = []
    

    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
         jsonapicall()
        tableview.delegate = self
        tableview.dataSource = self
    }
    func jsonapicall() {
        let params =  ["teacher_id":1] as Dictionary<String, AnyObject>
        
        var request = URLRequest(url: URL(string: "http://maestro.jodhaa.co.in/api/teacher/assignments/completed")!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: [])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
      
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! [String:Any]
               
                self.finalarr = json["Data"]! as! [[String : Any]]
                print(self.finalarr)
                DispatchQueue.main.async {
                    self.tableview.reloadData()
                }
                
                
            } catch {
                print("error")
            }
        })
        
        task.resume()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let arr = finalarr[indexPath.row]
        
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! coscell
        cell.lblname.text = arr["User_fullname"]as! String
        var value1 = Int()
        value1 = Int(arr["Total_assignment_completed"]as! NSNumber)
        cell.lblassignment.text = String(value1)
        cell.lblreting.text = ""
      
        return cell
    }
    
    }



