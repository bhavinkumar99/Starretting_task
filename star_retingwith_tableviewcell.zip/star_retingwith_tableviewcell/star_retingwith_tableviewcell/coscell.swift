//
//  coscell.swift
//  star_retingwith_tableviewcell
//
//  Created by Setblue's iMac on 03/04/19.
//  Copyright © 2019 I MAC. All rights reserved.
//

import UIKit

class coscell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var buttonview: UIButton!
    @IBOutlet weak var lblassignment: UILabel!
    @IBOutlet weak var lblreting: UILabel!
    @IBOutlet weak var lblname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
