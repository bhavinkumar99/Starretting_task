//
//  Model.swift
//  star_retingwith_tableviewcell
//
//  Created by Setblue's iMac on 03/04/19.
//  Copyright © 2019 I MAC. All rights reserved.
//

import Foundation

